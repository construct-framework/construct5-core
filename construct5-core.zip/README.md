# Construct5 Core #
Test bed... cutting edge technology... highly optimized... playground... internal use only ;)

The idea is something that we can use, something highly optimized (i.e. no parameters), and who knows what.

# Parameters #
Pretty much all parameters have been removed. You'll need to add stuff manually in the layout override to add head elements and such.

// TODO Move head elements to layout override

# Mobile Theme #
Mobile theme parameters have been removed. Define page element themes manually with attribute type <code>data-theme</code>. jQuery Mobile default theme swatches include a,b,c,d,e,f. See http://jquerymobile.com/demos/1.0/docs/api/themes.html
